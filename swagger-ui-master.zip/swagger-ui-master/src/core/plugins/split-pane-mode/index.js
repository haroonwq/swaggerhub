import * as components from "./components"

export default function SplitPaneModePlugin() {
  return {
    // statePlugins: {
    //   layout: {
    //     actions,
    //     selectors,
    //   }
    // },

    components,
  }
}
